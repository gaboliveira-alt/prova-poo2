export interface UserContract {
    sendMessage(to: string, message: string): string
}